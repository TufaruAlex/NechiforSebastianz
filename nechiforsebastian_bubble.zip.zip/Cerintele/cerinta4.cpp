//parcurgerea sirului de la ultima bula catre prima
#include<iostream>
using namespace std;
int n;
int V[100];
int main()
{
    cin>>n;
    int copie=n;
    for(int i=0;i<=n-1;i++)
    {cin>>V[i+1];}
    int gata=0;
    while(gata==0)
    {
        gata=1;
        for(int i=1;i<=n-1;i++)
        {
            if (V[i-1]>V[i])
            {
                swap(V[i-1],V[i]);
                gata=0;
            }
        }
        n--;
    }
n=copie;
for(int i=1;i<=n;i++)
{
    cout<<V[i]<<" ";
}
return 0;
}
