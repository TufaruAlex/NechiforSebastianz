//sortarea in ordine descrescatoare
#include<iostream>
using namespace std;
int n;
int V[100];
int main()
{
    cin>>n;
    int copie=n;
    for(int i=1;i<=n;i++)
    {cin>>V[i];}
    int gata=0;
    while(gata==0)
    {
        gata=1;
        for(int i=2;i<=n;i++)
        {
            if (V[i]>V[i-1])
            {
                swap(V[i-1],V[i]);
                gata=0;
            }
        }
        n--;
    }
n=copie;
for(int i=1;i<=n;i++)
{
    cout<<V[i]<<" ";
}
return 0;
}
